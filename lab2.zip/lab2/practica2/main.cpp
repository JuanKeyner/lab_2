#include <iostream>

using namespace std;


void problema2(int tamano);
int problema4(char s[]);
void problema6(char arreglo[]);
void problema8(char arreglo[]);

int main()
{
    int n;
    cout<<"numero del problema pares: ";
    cin>> n;
    switch (n) {

    case 2:
        cout<<"tamaño del arreglo";
        int tamano;
        cin>>tamano;

        problema2(tamano);


        break;
    case 4:
        char arreglo[10];
        cout<<"numero a convertir: ";
        cin>>arreglo;
        cout<<problema4(arreglo);

        break;

    case 6:
        char arreglo6[254];
        cout<<"cadena a convertir: ";
        cin>>arreglo6;
        problema6(arreglo6);

        break;

    case 8:

        char arreglo8[254];
        cout<<"cadena a convertir: ";
        cin>>arreglo8;
        problema8(arreglo8);

        break;



    }
    return 0;
}

void problema2(int tamano){

    //_________-Generar arreglo____________
    char arreglo[tamano];

        for(int i=0; i <= tamano; i++) //preguntar por corchetes
            arreglo[i] = 65 + rand() % (90 - 65);
        cout << arreglo<< endl<< endl;

    //________________________________________________
      int count;
      //int count2=0;

      for (int j=65;j <= 90; j++){
          count=0;

          for (int i= 0; i <= tamano; i++) { //recorre el arreglo, ojo solo < no cuenta algunas letras


              if (char(j)==arreglo[i]){
                  count++;
              }
             // cout<< char(j)<<"="<<count << endl;
          }
              cout<< char(j)<<"="<<count << endl;


          }







     // cout << "letra A = "<<count;
}


int problema4(char arreglo[]){
    int x,aux, count=10,suma=0;
    //recorrer arreglo para obtener ultima posición
    for (int i=0;i<10;i++){
        x=arreglo[i];
        if(x==0){//fin de arreglo
            x=i;//ultima posicion
            break;
        }


    }
    //__________________

    for (int j= x-1; j>=0 ;j--){
        aux=arreglo[j]-48;// llevarlo a la posicion en ascii
        aux*=(count/10);
        suma+= aux;
        count*=10;

    }

    return suma*1;







}


void problema6(char arreglo[]){

        int l;



        for(int i=0;i<20;i++){
            l=arreglo[i];
            if(l==0){
                l=i;
                break;
            }
        }
        for (int i = 0; i<=l; i++){
            if(arreglo[i]>=97 && arreglo[i]<=122){
                arreglo[i] -= 32;
            }
        }
        cout<<"En mayuscula: "<< arreglo;

}



void problema8(char arreglo[]){
    char arreglolet[sizeof(arreglo)];
    char arreglonum[sizeof(arreglo)];
    int count=1;
    int count2=1;


    for (int i= 0; i< sizeof(arreglo); i++){
        if (arreglo[i]>=97 && arreglo[i]<=122){
            arreglolet[count]=arreglo[i];
            count++;
        }if (arreglo[i]>=48 && arreglo[i]<=57){
            arreglonum[count2]=arreglo[i]-48;
            count2++;
        }


    }

    cout<<"TEXTO:" <<arreglolet<<" numeros: "<<arreglonum;

}
